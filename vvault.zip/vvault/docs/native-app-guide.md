# V Vault — Photo Vault — Native App Build Guide

Ye document us HTML prototype ko **real, installable iOS/Android app** banane ka roadmap hai. Prototype ne design aur UX already tay kar diya hai — ab yahan tech stack, security architecture, aur step-by-step plan hai.

---

## 1. Tech stack recommendation

| Option | Kab use karein | Trade-off |
|---|---|---|
| **Flutter** (Dart) | Ek codebase se iOS + Android, fast development, achi performance for image-heavy apps | Native se thoda bara app size |
| **React Native** | Agar team already JS/React janti hai | Photo-heavy encryption ke liye extra native modules likhne padtay hain |
| **Native (Swift + Kotlin)** | Sab se secure aur smooth, Keychain/Keystore ka full control | Do alag codebases, zyada waqt/cost |

**Suggestion:** Flutter se shuru karein — cross-platform hai, `flutter_secure_storage`, `local_auth` (biometrics), aur `sqflite`/`isar` jese packages already available hain jo is app ke liye perfect fit hain.

---

## 2. App architecture (screens → matches the prototype)

```
lib/
 ├─ main.dart
 ├─ screens/
 │   ├─ setup_screen.dart        (create password + security question)
 │   ├─ lock_screen.dart         (password / biometric unlock)
 │   ├─ forgot_password_flow/
 │   │   ├─ security_question_screen.dart
 │   │   └─ reset_password_screen.dart
 │   ├─ vault_home_screen.dart   (grid, albums, search)
 │   ├─ lightbox_screen.dart     (full photo, caption, album)
 │   └─ settings_screen.dart
 ├─ services/
 │   ├─ auth_service.dart        (password hash/verify, security Q&A)
 │   ├─ vault_storage_service.dart (encrypted photo read/write)
 │   ├─ album_service.dart
 │   └─ biometric_service.dart
 └─ models/
     ├─ photo.dart
     └─ album.dart
```

---

## 3. Security — sab se important hissa

Ye app ka poora selling point privacy hai, is liye security architecture theek se plan karna zaroori hai:

### Password
- Password **kabhi plaintext store na karein.** `Argon2` ya `bcrypt` se hash karke store karein (salt ke saath), Flutter mein `argon2` package ya native crypto library use karein.
- Security question ka answer bhi same tarha hash ho, plaintext nahi.
- Hash + salt ko `flutter_secure_storage` mein rakhein — ye iOS Keychain aur Android Keystore ko backend mein use karta hai (hardware-backed encryption).

### Photos
- Har photo ko app ke private sandbox folder mein **encrypted** save karein (AES-256), key device ke Keychain/Keystore se derive ho, user ke password se nahi (taake password change karne par photos dobara encrypt na karni parhein).
- Thumbnails bhi encrypted cache mein rakhein — gallery preview ke liye.
- **Kabhi bhi** photos ko device ki public/shared gallery (Photos app / MediaStore) mein na dalein jab tak user khud "Save" na kare.

### Auto-lock
- App background mein jaye ya kuch minute inactive rahe to auto-lock ho jaye (configurable timeout: 30s / 1min / 5min).
- App switcher/recents mein screenshot blur/hide karein (iOS: `isSecureTextEntry`-style overlay; Android: `FLAG_SECURE`).

### Biometric unlock (naya feature jo prototype mein illustrative tha)
- iOS: `LocalAuthentication` (Face ID / Touch ID)
- Android: `BiometricPrompt`
- Biometric hamesha **optional fallback** ho, password/security-question reset hamesha available rahe.

---

## 4. Offline-first data layer

- Poora app **bina internet permission** ke bhi chal sake — koi network call na ho.
- Local database: `sqflite` (SQLite) ya `isar` (faster, Flutter-native) — albums, captions, aur photo metadata store karne ke liye.
- Photo files device storage mein, database sirf paths + metadata rakhe (photos ko database blob mein na daalein — slow ho jata hai).

---

## 5. Permissions checklist

| Permission | Kab chahiye |
|---|---|
| Photo library read | Photos import karne ke liye |
| Photo library write (optional) | "Save" button ke liye, agar user gallery mein wapas save karna chahe |
| Biometric | Face/Touch unlock ke liye |
| **Camera/location/contacts** | Bilkul zaroorat nahi — na maangein, ye app ka trust factor kharab karega |

---

## 6. Build phases (realistic timeline for one developer)

1. **Week 1–2:** Setup + Lock + Forgot-password flow, secure password storage
2. **Week 2–3:** Vault home (grid), photo import, encrypted storage
3. **Week 3–4:** Albums, search, captions, lightbox
4. **Week 4–5:** Biometric unlock, auto-lock, settings, erase-vault
5. **Week 5–6:** Polish, animations (matching the aperture-unlock motion), testing on real devices, App Store / Play Store prep

---

## 7. Store submission notes

- **Privacy policy required** — even for a fully offline app, both App Store and Play Store ask for one (state clearly: no data leaves the device, no analytics, no ads).
- App Store review is stricter about "vault" apps — be explicit in the listing that it's a personal organizer, not a way to hide content from others without consent (avoid marketing language like "hide secret photos from your partner").
- Add an **App Store screenshot set** using the same brass/charcoal visual identity from the prototype for consistency.

---

## 8. Where the HTML prototype helps directly

- Color tokens, typography (Fraunces + Inter), spacing, and copy from `index.html` can be handed directly to your Flutter/React Native developer as the design spec — they don't need to guess the look.
- The logo (lens + keyhole mark) and generated app icons (`icon-192.png`, `icon-512.png`, `icon-180.png`) can be used as-is for the real app's icon set (just export additional sizes: 1024×1024 for App Store, adaptive icon layers for Android).
