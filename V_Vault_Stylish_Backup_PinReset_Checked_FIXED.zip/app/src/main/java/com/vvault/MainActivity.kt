package com.vvault

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.*
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.crypto.Cipher
import javax.crypto.CipherOutputStream
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("vault", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private var key: SecretKeySpec? = null
    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { importUri(it) }; renderVault()
    }
    private val backupCreate = registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) exportBackup(uri)
    }
    private val backupOpen = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) restoreBackup(uri)
    }

    override fun onCreate(b: Bundle?) { super.onCreate(b); showLock() }

    private fun bg() = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(16,18,24),Color.rgb(36,28,55))).apply { cornerRadius=42f }
    private fun card() = GradientDrawable().apply { setColor(Color.rgb(30,32,42)); cornerRadius=32f; setStroke(1,Color.rgb(65,67,82)) }
    private fun txt(s:String,size:Float=16f)=TextView(this).apply{ text=s; textSize=size; setTextColor(Color.WHITE) }
    private fun button(s:String)=Button(this).apply{ text=s; isAllCaps=false; textSize=15f; setTextColor(Color.WHITE); background=GradientDrawable().apply{setColor(Color.rgb(80,55,135));cornerRadius=22f} }

    private fun showLock() {
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;padding(34,50,34,34);background=bg()}
        val logo=TextView(this).apply{ text="◆"; textSize=64f; gravity=1; setTextColor(Color.rgb(190,150,255)) }
        val title=txt("V VAULT",30f); title.gravity=1
        val sub=txt("Your private space",15f); sub.gravity=1
        val pin=EditText(this).apply{hint="Enter PIN";setTextColor(Color.WHITE);setHintTextColor(Color.GRAY);inputType=2 or 0x10;gravity=1}
        val btn=button(if(prefs.contains("pin_hash")) "Unlock Vault" else "Create Vault")
        root.addView(logo,lp(-1,90)); root.addView(title,lp(-1,50)); root.addView(sub,lp(-1,35)); root.addView(pin,lp(-1,60)); root.addView(btn,lp(-1,58))
        if(prefs.contains("pin_hash")){
            val forgot=TextView(this).apply{text="Forgot PIN? Reset vault";setTextColor(Color.LTGRAY);gravity=1;setPadding(0,20,0,0)}
            root.addView(forgot,lp(-1,55)); forgot.setOnClickListener{confirmWipe()}
        }
        setContentView(root)
        btn.setOnClickListener{
            val p=pin.text.toString()
            if(p.length<4){pin.error="Minimum 4 digits";return@setOnClickListener}
            if(!prefs.contains("pin_hash")){
                prefs.edit().putString("pin_hash",hash(p)).apply(); key=derive(p); renderVault()
            } else if(prefs.getString("pin_hash","")==hash(p)){key=derive(p);renderVault()}
            else pin.error="Wrong PIN"
        }
    }

    private fun renderVault(){
        root.removeAllViews(); root.background=bg(); root.setPadding(22,35,22,22)
        val top=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val title=txt("V Vault",30f); val sub=txt("Private • Encrypted",13f)
        top.addView(title); top.addView(sub)
        val add=button("＋  Add Photos / Videos"); top.addView(add,lp(-1,58)); add.setOnClickListener{picker.launch(arrayOf("image/*","video/*"))}
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val backup=button("Backup"); val restore=button("Restore"); val settings=button("Settings")
        actions.addView(backup,lp(0,55,1f)); actions.addView(restore,lp(0,55,1f)); actions.addView(settings,lp(0,55,1f))
        top.addView(actions)
        root.addView(top); backup.setOnClickListener{backupCreate.launch("VVault_Backup_${System.currentTimeMillis()}.vvault")}
        restore.setOnClickListener{backupOpen.launch(arrayOf("*/*"))}; settings.setOnClickListener{showSettings()}
        val dir=vaultDir(); val files=dir.listFiles()?.filter{!it.name.endsWith(".mime")&&!it.name.endsWith(".tmp")}?.sortedByDescending{it.lastModified()}?:emptyList()
        root.addView(txt("${files.size} encrypted item${if(files.size==1)"" else "s"}",14f).apply{setPadding(5,20,5,8)})
        if(files.isEmpty()){root.addView(txt("Your vault is empty.\nAdd photos or videos to keep them private.",17f).apply{gravity=1;setPadding(20,80,20,20)})}
        files.forEach{ f->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;padding(10,8,10,8);background=card()}
            val icon=txt(if(readMime(f)?.startsWith("video/")==true)"▶" else "▣",25f)
            val name=txt(f.nameWithoutExtension,15f); val open=button("Open"); val del=button("Delete")
            row.addView(icon,lp(55,65));row.addView(name,lp(0,65,1f));row.addView(open,lp(82,55));row.addView(del,lp(82,55));root.addView(row,lp(-1,75))
            open.setOnClickListener{openEncrypted(f)};del.setOnClickListener{confirmDelete(f)}
        }
    }

    private fun showSettings(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;padding(28,20,28,10)}
        val change=button("Change PIN"); val about=txt("V Vault\nAES-GCM encrypted local vault",16f)
        box.addView(about);box.addView(change,lp(-1,58)); AlertDialog.Builder(this).setTitle("Settings").setView(box).setPositiveButton("Close",null).show()
        change.setOnClickListener{showChangePin()}
    }
    private fun showChangePin(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;padding(25,10,25,10)}
        val old=EditText(this).apply{hint="Current PIN";inputType=2 or 0x10};val np=EditText(this).apply{hint="New PIN (4+ digits)";inputType=2 or 0x10}
        box.addView(old);box.addView(np)
        AlertDialog.Builder(this).setTitle("Change PIN").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Change"){_,_->changePin(old.text.toString(),np.text.toString())}.show()
    }
    private fun changePin(old:String,np:String){
        if(hash(old)!=prefs.getString("pin_hash","")||np.length<4){toast("Current PIN incorrect or new PIN invalid");return}
        val oldKey=derive(old);val newKey=derive(np);val dir=vaultDir()
        try{dir.listFiles()?.filter{it.isFile&&!it.name.endsWith(".mime")&&!it.name.endsWith(".tmp")}?.forEach{f->
            val plain=decryptWith(f,oldKey);encryptWith(plain,f,newKey)
        };key=newKey;prefs.edit().putString("pin_hash",hash(np)).apply();toast("PIN changed successfully")}
        catch(e:Exception){toast("PIN change failed; your files were not changed safely")}
    }

    private fun confirmWipe(){
        AlertDialog.Builder(this).setTitle("Reset Vault?").setMessage("Forgotten PIN cannot decrypt your files. Resetting will permanently delete encrypted vault data. Backups are not deleted.")
            .setNegativeButton("Cancel",null).setPositiveButton("Delete & Reset"){_,_->vaultDir().deleteRecursively();prefs.edit().clear().apply();key=null;showLock()}.show()
    }
    private fun confirmDelete(f:File){AlertDialog.Builder(this).setTitle("Delete item?").setMessage("This encrypted file will be removed.").setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->f.delete();File(f.parentFile,f.name+".mime").delete();renderVault()}.show()}

    private fun exportBackup(uri:Uri){
        try{contentResolver.openOutputStream(uri)?.use{os->ZipOutputStream(BufferedOutputStream(os)).use{zos->
            vaultDir().listFiles()?.filter{it.isFile&&!it.name.endsWith(".tmp")}?.forEach{f->zos.putNextEntry(ZipEntry(f.name));f.inputStream().use{it.copyTo(zos)};zos.closeEntry()}
        }};toast("Encrypted backup created. Keep it safe.")
        }catch(e:Exception){toast("Backup failed")}
    }
    private fun restoreBackup(uri:Uri){
        try{
            val dir=vaultDir();dir.mkdirs()
            contentResolver.openInputStream(uri)?.use{ins->ZipInputStream(BufferedInputStream(ins)).use{zis->
                var e=zis.nextEntry;while(e!=null){if(!e.isDirectory&&e.name.matches(Regex("[A-Za-z0-9_.-]+")) && e.name != "." && e.name != ".."){val f=File(dir,e.name);FileOutputStream(f).use{zis.copyTo(it)}};zis.closeEntry();e=zis.nextEntry}
            }};toast("Backup restored");renderVault()
        }catch(e:Exception){toast("Restore failed")}
    }

    private fun importUri(uri:Uri){
        try{
            val bytes=contentResolver.openInputStream(uri)?.use{it.readBytes()}?:error("open")
            val mime=detectMime(bytes,contentResolver.getType(uri))?:run{toast("Unsupported format");return}
            val dir=vaultDir();val name="v_${System.currentTimeMillis()}_${kotlin.math.abs((uri.toString()).hashCode())}.bin";val out=File(dir,name)
            encrypt(ByteArrayInputStream(bytes),out);File(dir,"$name.mime").writeText(mime)
        }catch(e:Exception){toast("Import failed")}
    }
    private fun openEncrypted(f:File){
        val data=try{decrypt(f)}catch(e:Exception){toast("Cannot decrypt");return};val mime=detectMime(data,readMime(f))
        if(mime?.startsWith("image/")==true){
            val bitmap=android.graphics.BitmapFactory.decodeByteArray(data,0,data.size)
            if(bitmap==null){toast("This image format is not supported on this Android version");return}
            val iv=ImageView(this).apply{setImageBitmap(bitmap);adjustViewBounds=true}
            AlertDialog.Builder(this).setView(iv).setPositiveButton("Close",null).show()
        }else if(mime?.startsWith("video/")==true){
            val ext=if(mime=="video/webm")".webm" else if(mime=="video/3gpp")".3gp" else ".mp4";val temp=File.createTempFile("view_",ext,cacheDir);temp.writeBytes(data)
            val vv=VideoView(this);vv.setVideoURI(FileProvider.getUriForFile(this,"$packageName.fileprovider",temp));vv.setMediaController(MediaController(this));vv.setOnPreparedListener{it.start()};vv.setOnErrorListener{_,_,_->toast("Video codec not supported");true}
            AlertDialog.Builder(this).setView(vv).setPositiveButton("Close"){_,_->temp.delete()}.setOnDismissListener{temp.delete()}.show()
        }else toast("Unsupported file type")
    }
    private fun encrypt(input:InputStream,out:File)=encryptWith(input.readBytes(),out,key?:error("Locked"))
    private fun encryptWith(bytes:ByteArray,out:File,k:SecretKeySpec){val iv=ByteArray(12);java.security.SecureRandom().nextBytes(iv);val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,k,GCMParameterSpec(128,iv));FileOutputStream(out).use{fos->fos.write(iv);CipherOutputStream(fos,c).use{it.write(bytes)}}}
    private fun decrypt(f:File)=decryptWith(f,key?:error("Locked"))
    private fun decryptWith(f:File,k:SecretKeySpec):ByteArray{val a=f.readBytes();val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,k,GCMParameterSpec(128,a.copyOfRange(0,12)));return c.doFinal(a.copyOfRange(12,a.size))}
    private fun readMime(f:File)=try{File(f.parentFile,f.name+".mime").takeIf{it.exists()}?.readText()?.trim()}catch(_:Exception){null}
    private fun detectMime(b:ByteArray,p:String?):String?{
        if(b.size>=3&&b[0].toInt()and 255==255&&b[1].toInt()and 255==216)return"image/jpeg"
        if(b.size>=8&&b[0].toInt()and 255==137&&b[1].toInt()and 255==80&&b[2].toInt()and 255==78)return"image/png"
        if(b.size>=6&&String(b.copyOfRange(0,6)) in listOf("GIF87a","GIF89a"))return"image/gif"
        if(b.size>=12&&String(b.copyOfRange(0,4))=="RIFF"&&String(b.copyOfRange(8,12))=="WEBP")return"image/webp"
        if(b.size>=12&&String(b.copyOfRange(4,8))=="ftyp"){
            val brand=String(b.copyOfRange(8,12))
            return when {
                brand.startsWith("hei") || brand.startsWith("heix") || brand.startsWith("hevc") || brand.startsWith("hevx") || brand=="mif1" || brand=="msf1" -> "image/heif"
                brand.startsWith("avif") || brand.startsWith("avis") -> "image/avif"
                else -> "video/mp4"
            }
        }
        if(b.size>=4&&(b[0].toInt()and 255)==26&&(b[1].toInt()and 255)==69&&(b[2].toInt()and 255)==223&&(b[3].toInt()and 255)==163)return"video/webm"
        return p?.takeIf{it.startsWith("image/")||it.startsWith("video/")}
    }
    private fun derive(pin:String):SecretKeySpec{val spec=PBEKeySpec(pin.toCharArray(),"V_VAULT_LOCAL_SALT".toByteArray(),120000,256);return SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded,"AES")}
    private fun hash(s:String)=MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString(""){"%02x".format(it)}
    private fun vaultDir()=File(filesDir,"vault").apply{mkdirs()}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    private fun lp(w:Int,h:Int,weight:Float=0f)=LinearLayout.LayoutParams(w,h).apply{if(weight>0) this.weight=weight}
    private fun LinearLayout.padding(l:Int,t:Int,r:Int,b:Int){setPadding(l,t,r,b)}
}
