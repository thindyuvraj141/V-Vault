# V Vault — corrected build configuration

## Build requirements
- JDK 17
- Gradle 8.2
- Android SDK 34

The project uses:
- Android Gradle Plugin 8.2.2
- Kotlin 1.9.22
- Compose Compiler 1.5.8
- Compose BOM 2024.02.01

## Build
From the project root:

```bash
gradle assembleDebug
```

The APK will be generated at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Important
This version fixes the Android manifest namespace, adds the missing Material 3 theme resource, explicitly targets Java/Kotlin 17, removes the missing launcher icon reference, updates AndroidX Security Crypto to 1.1.0, and makes photo-copy handling safer.

The GitHub Actions workflow installs Gradle 8.2 directly, so the project does not depend on a checked-in Gradle wrapper JAR.
