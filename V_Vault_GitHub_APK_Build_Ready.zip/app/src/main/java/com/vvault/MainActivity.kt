package com.vvault

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.io.File

val GoldColor = Color(0xFFFFD700)
val DarkBackground = Color(0xFF121212)

class VaultManager(private val context: Context) {

    private val masterKey = androidx.security.crypto.MasterKey.Builder(context)
        .setKeyScheme(androidx.security.crypto.MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = androidx.security.crypto.EncryptedSharedPreferences.create(
        context,
        "v_vault_prefs",
        masterKey,
        androidx.security.crypto.EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        androidx.security.crypto.EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun isSetup(): Boolean = prefs.contains(KEY_PIN)

    fun setup(pin: String, answer: String) {
        prefs.edit()
            .putString(KEY_PIN, pin)
            .putString(KEY_ANSWER, answer.trim().lowercase())
            .apply()
    }

    fun verifyPin(pin: String): Boolean =
        prefs.getString(KEY_PIN, null) == pin

    fun verifyAnswer(answer: String): Boolean =
        prefs.getString(KEY_ANSWER, null) == answer.trim().lowercase()

    fun resetPin(pin: String) {
        prefs.edit().putString(KEY_PIN, pin).apply()
    }

    fun savePhoto(uri: Uri): Boolean {
        return try {
            val input = context.contentResolver.openInputStream(uri) ?: return false

            val file = File(
                context.filesDir,
                "vault_${System.currentTimeMillis()}.jpg"
            )

            input.use { source ->
                file.outputStream().use { output ->
                    source.copyTo(output)
                }
            }

            true
        } catch (_: Exception) {
            false
        }
    }

    fun getPhotos(): List<File> =
        context.filesDir
            .listFiles { _, name -> name.startsWith("vault_") }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()

    companion object {
        private const val KEY_PIN = "pin"
        private const val KEY_ANSWER = "ans"
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val vaultManager = VaultManager(this)

        setContent {
            var screen by remember {
                mutableStateOf(
                    if (vaultManager.isSetup()) Screen.LOGIN else Screen.SETUP
                )
            }

            Surface(
                modifier = Modifier.fillMaxSize(),
                color = DarkBackground
            ) {
                when (screen) {
                    Screen.SETUP -> SetupScreen(vaultManager) {
                        screen = Screen.LOGIN
                    }

                    Screen.LOGIN -> LoginScreen(
                        vaultManager,
                        onOk = { screen = Screen.GALLERY },
                        onReset = { screen = Screen.RESET }
                    )

                    Screen.RESET -> ResetScreen(vaultManager) {
                        screen = Screen.LOGIN
                    }

                    Screen.GALLERY -> GalleryScreen(vaultManager)
                }
            }
        }
    }
}

private object Screen {
    const val SETUP = "SETUP"
    const val LOGIN = "LOGIN"
    const val RESET = "RESET"
    const val GALLERY = "GALLERY"
}

@Composable
fun SetupScreen(vm: VaultManager, onDone: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "V VAULT SETUP",
            fontSize = 28.sp,
            color = GoldColor,
            fontWeight = FontWeight.Bold
        )

        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = pin,
            onValueChange = {
                if (it.length <= 4 && it.all(Char::isDigit)) pin = it
            },
            label = { Text("4-Digit PIN") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = answer,
            onValueChange = { answer = it },
            label = { Text("Security Q: Favorite City?") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(16.dp))

        Button(
            onClick = {
                if (pin.length == 4 && answer.isNotBlank()) {
                    vm.setup(pin, answer)
                    onDone()
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = GoldColor)
        ) {
            Text("Save & Lock", color = Color.Black)
        }
    }
}

@Composable
fun LoginScreen(
    vm: VaultManager,
    onOk: () -> Unit,
    onReset: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "V VAULT",
            fontSize = 32.sp,
            color = GoldColor,
            fontWeight = FontWeight.Bold
        )

        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = pin,
            onValueChange = {
                if (it.length <= 4 && it.all(Char::isDigit)) pin = it
            },
            label = { Text("Enter PIN") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(16.dp))

        Button(
            onClick = {
                if (vm.verifyPin(pin)) {
                    onOk()
                } else {
                    Toast.makeText(context, "Wrong PIN", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = GoldColor)
        ) {
            Text("Unlock", color = Color.Black)
        }

        TextButton(onClick = onReset) {
            Text("Forgot PIN?", color = GoldColor)
        }
    }
}

@Composable
fun ResetScreen(vm: VaultManager, onDone: () -> Unit) {
    var answer by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var verified by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "RESET PIN",
            fontSize = 24.sp,
            color = GoldColor,
            fontWeight = FontWeight.Bold
        )

        Spacer(Modifier.height(16.dp))

        if (!verified) {
            OutlinedTextField(
                value = answer,
                onValueChange = { answer = it },
                label = { Text("Favorite City?") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(16.dp))

            Button(
                onClick = {
                    if (vm.verifyAnswer(answer)) {
                        verified = true
                    } else {
                        Toast.makeText(
                            context,
                            "Wrong Answer",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = GoldColor)
            ) {
                Text("Verify", color = Color.Black)
            }
        } else {
            OutlinedTextField(
                value = newPin,
                onValueChange = {
                    if (it.length <= 4 && it.all(Char::isDigit)) newPin = it
                },
                label = { Text("New 4-Digit PIN") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(16.dp))

            Button(
                onClick = {
                    if (newPin.length == 4) {
                        vm.resetPin(newPin)
                        onDone()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = GoldColor)
            ) {
                Text("Set New PIN", color = Color.Black)
            }
        }
    }
}

@Composable
fun GalleryScreen(vm: VaultManager) {
    var photos by remember { mutableStateOf(vm.getPhotos()) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri ?: return@rememberLauncherForActivityResult

        if (vm.savePhoto(uri)) {
            photos = vm.getPhotos()
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { launcher.launch("image/*") },
                containerColor = GoldColor
            ) {
                Text("+ Add Photo", color = Color.Black)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(
                text = "V VAULT GALLERY",
                fontSize = 20.sp,
                color = GoldColor,
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.height(16.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(
                    items = photos,
                    key = { it.absolutePath }
                ) { photo ->
                    AsyncImage(
                        model = photo,
                        contentDescription = "Vault photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(100.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(
                                width = 1.dp,
                                color = GoldColor,
                                shape = RoundedCornerShape(8.dp)
                            )
                    )
                }
            }
        }
    }
}
