# V Vault — Offline encrypted vault
Complete Android Studio starter for an offline photo/video vault.
- No Firebase, OAuth, account or network permission.
- Local PIN gate.
- AES-GCM encrypted app-private files using a PIN-derived key.
- Photo/video import.
- After successful import, Android 11+ is asked to confirm deletion of the original MediaStore item.
- Basic image preview and video playback.
- Delete from vault.

Important: This source still needs a local Android build/signing step to produce the APK. The chat environment cannot install the Android SDK/Gradle toolchain or sign an APK reliably.
