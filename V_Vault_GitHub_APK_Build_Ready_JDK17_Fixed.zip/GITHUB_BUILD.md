# Phone-only GitHub APK build

1. Create a GitHub repository.
2. Upload all files/folders from this project (not the outer ZIP folder).
3. Open the repository's Actions tab.
4. Select **Build V Vault APK** and press **Run workflow** (or push to main/master).
5. After the run finishes, open the workflow run and download the **V-Vault-debug-apk** artifact.

GitHub Actions runs the Android/Gradle build on a hosted runner, so no PC is required on your side.
