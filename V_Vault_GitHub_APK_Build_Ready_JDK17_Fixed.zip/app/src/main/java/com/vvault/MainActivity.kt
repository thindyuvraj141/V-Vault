package com.vvault

import android.app.*
import android.content.*
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.*
import android.widget.*
import android.media.MediaPlayer
import android.view.TextureView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.*
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("vault", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private var key: SecretKeySpec? = null
    private val picker = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        uris.forEach { importUri(it) }
        renderVault()
    }

    override fun onCreate(b: Bundle?) { super.onCreate(b); showLock() }

    private fun showLock() {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(40,60,40,40) }
        val title=TextView(this).apply { text="V VAULT\n🔒"; textSize=30f; gravity=1 }
        val pin=EditText(this).apply { hint="4+ digit PIN"; inputType=2 or 0x10 }
        val btn=Button(this).apply { text=if(prefs.contains("pin_hash")) "UNLOCK" else "SET PIN" }
        root.addView(title); root.addView(pin); root.addView(btn); setContentView(root)
        btn.setOnClickListener {
            val p=pin.text.toString()
            if(p.length<4){pin.error="Minimum 4 digits";return@setOnClickListener}
            if(!prefs.contains("pin_hash")){
                prefs.edit().putString("pin_hash",hash(p)).apply(); key=derive(p); renderVault()
            } else if(prefs.getString("pin_hash","")==hash(p)){
                key=derive(p); renderVault()
            } else pin.error="Wrong PIN"
        }
    }

    private fun renderVault() {
        root.removeAllViews()
        val head=TextView(this).apply{text="V Vault";textSize=27f}
        val add=Button(this).apply{text="＋ Add Photos / Videos"}
        root.addView(head); root.addView(add)
        add.setOnClickListener{picker.launch("*/*")}
        val dir=File(filesDir,"vault"); dir.mkdirs()
        val files=dir.listFiles()?.sortedByDescending{it.lastModified()} ?: emptyList()
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        if(files.isEmpty()) root.addView(TextView(this).apply{text="Your private vault is empty.";textSize=17f})
        for(f in files){
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(0,12,0,12)}
            val t=TextView(this).apply{text=f.nameWithoutExtension;textSize=16f}
            val open=Button(this).apply{text="Open"}
            val del=Button(this).apply{text="Delete"}
            row.addView(t,LinearLayout.LayoutParams(0,-2,1f));row.addView(open);row.addView(del);list.addView(row)
            open.setOnClickListener{openEncrypted(f)}
            del.setOnClickListener{f.delete();renderVault()}
        }
        root.addView(list)
    }

    private fun importUri(uri:Uri){
        try{
            val dir=File(filesDir,"vault").apply{mkdirs()}
            val name="v_"+System.currentTimeMillis()+"_"+(uri.lastPathSegment?.hashCode() ?: 0)+".bin"
            val out=File(dir,name)
            contentResolver.openInputStream(uri)?.use{inp-> encrypt(inp,out)}
            // Ask Android to remove the original MediaStore item only after successful encryption.
            if(android.os.Build.VERSION.SDK_INT>=30){
                try{
                    val pending=MediaStore.createDeleteRequest(contentResolver, listOf(uri))
                    startIntentSenderForResult(pending.intentSender, 991, null, 0, 0, 0, null)
                }catch(_:Exception){}
            }
        }catch(e:Exception){Toast.makeText(this,"Import failed",Toast.LENGTH_SHORT).show()}
    }

    private fun encrypt(input:InputStream,out:File){
        val k=key ?: error("Locked")
        val iv=ByteArray(12); java.security.SecureRandom().nextBytes(iv)
        val c=Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE,k,GCMParameterSpec(128,iv))
        FileOutputStream(out).use{fos->fos.write(iv); javax.crypto.CipherOutputStream(fos,c).use{cos->input.copyTo(cos)}}
    }
    private fun decrypt(f:File):ByteArray{
        val all=f.readBytes(); val iv=all.copyOfRange(0,12)
        val c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE,key,GCMParameterSpec(128,iv))
        return c.doFinal(all.copyOfRange(12,all.size))
    }
    private fun openEncrypted(f:File){
        val data=try{decrypt(f)}catch(e:Exception){Toast.makeText(this,"Cannot decrypt",Toast.LENGTH_SHORT).show();return}
        val temp=File(cacheDir,"view_${System.currentTimeMillis()}")
        temp.writeBytes(data)
        val mime=guessMime(data)
        if(mime.startsWith("image/")){
            val iv=ImageView(this).apply{setImageBitmap(BitmapFactory.decodeByteArray(data,0,data.size));adjustViewBounds=true}
            AlertDialog.Builder(this).setView(iv).setPositiveButton("Close",null).show()
        }else{
            val player=VideoView(this); player.setVideoURI(Uri.fromFile(temp)); player.setMediaController(android.widget.MediaController(this)); player.start()
            AlertDialog.Builder(this).setView(player).setPositiveButton("Close",null).show()
        }
    }
    private fun guessMime(b:ByteArray):String=when{
        b.size>8 && b[0].toInt()==0xFF && b[1].toInt()==0xD8 -> "image/jpeg"
        b.size>8 && b[0].toInt()==0x89 && b[1].toInt()==0x50 -> "image/png"
        b.size>12 && String(b.copyOfRange(4,8))=="ftyp" -> "video/mp4"
        else -> "application/octet-stream"
    }
    private fun derive(pin:String):SecretKeySpec{
        val salt="V_VAULT_LOCAL_SALT".toByteArray()
        val spec=PBEKeySpec(pin.toCharArray(),salt,120000,256)
        val bytes=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return SecretKeySpec(bytes,"AES")
    }
    private fun hash(s:String)=MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString(""){"%02x".format(it)}
}
